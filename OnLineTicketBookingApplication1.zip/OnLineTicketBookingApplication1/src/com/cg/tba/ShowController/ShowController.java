package com.cg.tba.ShowController;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.tba.Service.IShowService;
import com.cg.tba.Service.ShowServiceImpl;
import com.cg.tba.bean.ShowDetails;

@WebServlet({"/ShowController","./Booknow","./UpdatesSeats"})
public class ShowController extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public ShowController() {
        super();
       
    }

	
	public void init(ServletConfig config) throws ServletException {
		
	}

	
	public void destroy() {
		
	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		doPost(request,response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		System.out.println("In doPost() Controller");
	 IShowService service=new ShowServiceImpl();
		String path=request.getServletPath();
		System.out.println(path);
		String url= null;
		switch(path)
		{

		case "/ShowController":
				List<ShowDetails> showList=service.getShowDetails();
				System.out.println(showList);
				request.setAttribute("showList", showList);
				url="ShowDetails.jsp";
		break;
		
		case "/BookNow":
				String showId=request.getParameter("showid");
				request.setAttribute("showid", showId);
				System.out.println(showId);
				ShowDetails showDetails=service.getShowDetail(showId);
				System.out.println(showDetails);
				request.setAttribute("showDetails", showDetails);
				url="BookNow.jsp";
		break;

		case "/UpdateSeats":
				String Id=(String) request.getAttribute("showid");
				System.out.println(Id);
				int noOfSeats=Integer.parseInt(request.getParameter("txtNoOfSeats"));
				System.out.println(noOfSeats);
				int status=service.updateShowDetails(Id,noOfSeats);
				System.out.println(status);
		if(status==1)
		{
				String showName=request.getParameter("txtShowName");
				String customerName=request.getParameter("txtCName");
				String mobileNo=request.getParameter("txtMNo");
				String seats=request.getParameter("txtNoOfSeats");
				String price=request.getParameter("txtTicketPrice");
				request.setAttribute("showName",showName);
				request.setAttribute("customerName",customerName);
				request.setAttribute("mobileNo",mobileNo);
				request.setAttribute("seats",seats);
				request.setAttribute("price",price);
				url="Sucess.jsp";
		}
			else
			{
				url="Error.jsp";
			}
		break;
			}
			RequestDispatcher rd = request.getRequestDispatcher(url) ;
			rd.forward(request, response);
		}
}