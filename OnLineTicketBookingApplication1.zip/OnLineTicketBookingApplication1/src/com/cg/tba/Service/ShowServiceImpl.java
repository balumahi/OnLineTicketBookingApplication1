package com.cg.tba.Service;

import java.util.List;

import com.cg.tba.Dao.IShowDao;
import com.cg.tba.Dao.ShowDaoImpl;
import com.cg.tba.bean.ShowDetails;

public class ShowServiceImpl implements IShowService{

	
	IShowDao showDao;
	public  ShowServiceImpl()
	{
		showDao = new ShowDaoImpl();
	}
	@Override
	public ShowDetails getShowDetail(String showid) {
		
		return showDao.getShowDetail(showid);
	}
	@Override
	public List<ShowDetails> getShowDetails() {
		
		return showDao.getShowDetails();
	}
	@Override
	public int updateShowDetails(String showId, int noOfSeats) {
		
		return showDao.updateShowDetails(showId, noOfSeats);
	}
	
}
