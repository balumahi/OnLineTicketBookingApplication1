package com.cg.tba.Service;

import java.util.List;

import com.cg.tba.bean.ShowDetails;

public interface IShowService {
	public  ShowDetails getShowDetail(String showid);

	public List<ShowDetails> getShowDetails ();
	public int updateShowDetails(String showId, int noOfSeats);

}
