package com.cg.tba.Dao;

import java.util.List;

import com.cg.ebc.exception.BookShowException;
import com.cg.tba.bean.ShowDetails;

public interface IShowDao {
	
	
	public  ShowDetails getShowDetail(String showid) throws BookShowException;
	public List<ShowDetails> getShowDetails ();
	public int updateShowDetails(String showId, int noOfSeats);

}
