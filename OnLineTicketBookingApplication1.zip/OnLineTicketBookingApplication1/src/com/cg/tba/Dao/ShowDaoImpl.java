package com.cg.tba.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cg.ebc.exception.BookShowException;
import com.cg.ebc.util.DBUtil;
import com.cg.tba.bean.ShowDetails;


public class ShowDaoImpl implements IShowDao {

		Connection con;
		Statement st;
		PreparedStatement pst;
		ResultSet rs;

@Override

	public List<ShowDetails> getShowDetails() {
	List<ShowDetails> showList=new ArrayList<ShowDetails>();
	ShowDetails showDetails=null;
	try {
		con=DBUtil.getConnection();
		String sql="SELECT * FROM SHOWDETAILS";
		Statement st=con.createStatement();
		ResultSet rs=st.executeQuery(sql);
			while(rs.next())
			{

				showDetails=new ShowDetails();
				showDetails.setShowId(rs.getString(1));
				showDetails.setShowName(rs.getString(2));
				showDetails.setLocation(rs.getString(3));
				showDetails.setShowDate(rs.getDate(4));
				showDetails.setAvailableSeats(rs.getInt(5));
				showDetails.setTicketPrice(rs.getDouble(6));
				showList.add(showDetails);
				}
			}catch (SQLException e) {
				e.printStackTrace();
				}
			return showList;

}

@Override

	public ShowDetails getShowDetail(String showId) {
	ShowDetails showDetails=null;
	try {
		con=DBUtil.getConnection();
			System.out.println("In ShowDetails dao con is "+con);
			String selectQuery="SELECT * FROM SHOWDETAILS WHERE SHOWID=?";
			pst=con.prepareStatement(selectQuery);
			pst.setString(1,showId);
			rs=pst.executeQuery();
			rs.next();
			showDetails=new ShowDetails();
			showDetails.setShowId(rs.getString(1));
			showDetails.setShowName(rs.getString(2));
			showDetails.setLocation(rs.getString(3));
			showDetails.setShowDate(rs.getDate(4));
			showDetails.setAvailableSeats(rs.getInt(5));
			showDetails.setTicketPrice(rs.getDouble(6));
			}
	catch (SQLException e) {
		e.printStackTrace();
}
	finally{
		try{
			rs.close();
			pst.close();
			con.close();
}
		catch (SQLException e) {
			e.printStackTrace();
}
}
	return showDetails;
}

@Override

	public int updateShowDetails(String showId,int noOfSeats) {
	int flag=0;
	try {
	con=DBUtil.getConnection();
	String selectQuery="SELECT AvSeats FROM SHOWDETAILS WHERE SHOWID=?";
	pst=con.prepareStatement(selectQuery);
	pst.setString(1,showId);
	rs=pst.executeQuery();
	if(rs.next()==false)
	throw new BookShowException("Invalid Show Id");
	int availableSeats=rs.getInt(1);
	if(availableSeats>=noOfSeats)
		{
		PreparedStatement pst=con.prepareStatement("update ShowDetails set AvSeats=AvSeats-? where ShowId=?");
		pst.setInt(1,noOfSeats);
		pst.setString(2,showId);
		pst.execute();
		flag=1;	
		}
	else
	{
	flag=0;
	}
	} 
	catch (SQLException e) 
	{
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return flag;

}

}